//
//  ContentView.swift
//  Juego Multimedia
//
//  Created by Fernando Torres on 16/7/24.
//

import SwiftUI
import SwiftData


struct ContentView: View {
    @StateObject var appState = AppState()

    var body: some View {
        if appState.isLoggedIn {
            TabView {
                HomeView()
                    .tabItem {
                        Label("Inicio", systemImage: "house.fill")
                    }
                    .environmentObject(appState)

                RewardsView()
                    .tabItem {
                        Label("Recompensas", systemImage: "gift.fill")
                    }

                ChallengesView()
                    .tabItem {
                        Label("Retos", systemImage: "flag.fill")
                    }

                ProfileView()
                    .tabItem {
                        Label("Perfil", systemImage: "person.fill")
                    }
                    .background(Color.blue)
            }
        } else {
            LoginView()
                .environmentObject(appState)
                .background(softOrange)
        }
    }
    let softOrange = Color(red: 1.0, green: 0.8, blue: 0.0, opacity: 1.0)
}
