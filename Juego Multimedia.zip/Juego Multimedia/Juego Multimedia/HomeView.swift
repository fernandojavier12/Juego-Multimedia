import SwiftUI

struct HomeView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        NavigationView {
            VStack {
                // Parte superior con la bandera, puntos de experiencia y días usando la aplicación
                HStack {
                    Image(systemName: "flag.fill")
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.red)

                    Spacer()

                    HStack(spacing: 16) {
                        HStack(spacing: 4) {
                            Image(systemName: "flame.fill")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.orange)
                            Text("153")
                        }

                        HStack(spacing: 4) {
                            Image("calen")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.blue)
                            Text("1360")
                        }

                        HStack(spacing: 4) {
                            Image(systemName: "heart.fill")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.red)
                            Text("5")
                        }

                        HStack(spacing: 4) {
                            Image(systemName: "sparkles")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.purple)
                            Text("1")
                        }
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 5)
                .padding([.leading, .trailing, .top])

                //Spacer()
                
                // Contenido existente
                Text("Niveles de hoy")
                    .font(.title)
                    .padding()
                Spacer()
                NavigationLink(destination: Level1View()) {
                    Text("Nivel 1")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.bottom, 20)

                NavigationLink(destination: Level2View()) {
                    Text("Nivel 2")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }

                Spacer()
            }
            .navigationTitle("Inicio")
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(AppState())
    }
}
