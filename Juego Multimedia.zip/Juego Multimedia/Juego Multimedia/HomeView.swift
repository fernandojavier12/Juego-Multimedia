import SwiftUI

struct HomeView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        NavigationView {
            VStack {
                Text("Bienvenido a Language Challenge")
                    .font(.largeTitle)
                    .padding()

                NavigationLink(destination: Level1View()) {
                    Text("Nivel 1")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.bottom, 20)

                NavigationLink(destination: Level2View()) {
                    Text("Nivel 2")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
            .navigationTitle("Inicio")
        }
    }
}
