import SwiftUI

struct CompletePhraseLessonView: View {
    @EnvironmentObject var appState: AppState
    @State private var answer = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    let correctAnswer = "prefers"

    var body: some View {
        VStack {
            Text("Completa la frase:")
            Text("He ______ to study in the morning.")
                .padding()
            
            TextField("Tu respuesta", text: $answer)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button("Enviar") {
                if answer.lowercased() == correctAnswer {
                    appState.score += 100
                    alertMessage = "¡Correcto! Ganaste 100 puntos."
                } else {
                    alertMessage = "Respuesta incorrecta. Inténtalo de nuevo."
                }
                showAlert = true
            }
            .padding()
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Resultado"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
        .navigationTitle("Completar la frase")
        .padding()
    }
}
