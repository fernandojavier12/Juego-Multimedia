import SwiftUI

struct ProfileView: View {
    @State private var firstName = "Fernando"
    @State private var lastName = "Torres"
    @State private var age = "24"
    @State private var userType = "Estudiante"
    @State private var proficiencyLevel = "Intermedio"
    @State private var showAlert = false
    @State private var showAvatarSelection = false
    @EnvironmentObject var appState: AppState

    var body: some View {
        NavigationView {
            VStack {
                // Parte superior con la bandera, puntos de experiencia y días usando la aplicación
                HStack {
                    Image(systemName: "flag.fill")
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.red)

                    Spacer()

                    HStack(spacing: 16) {
                        HStack(spacing: 4) {
                            Image(systemName: "flame.fill")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.orange)
                            Text("153") // Datos específicos para ProfileView
                        }

                        HStack(spacing: 4) {
                            Image("calen")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.blue)
                            Text("1360") // Datos específicos para ProfileView
                        }

                        HStack(spacing: 4) {
                            Image(systemName: "heart.fill")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.red)
                            Text("5") // Datos específicos para ProfileView
                        }

                        HStack(spacing: 4) {
                            Image(systemName: "sparkles")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.purple)
                            Text("1") // Datos específicos para ProfileView
                        }
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 5)
                .padding([.leading, .trailing, .top])

                VStack {
                    ZStack(alignment: .topTrailing) {
                        Image(appState.selectedAvatar)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 110, height: 110)
                            .clipShape(Circle())
                            .padding(.top, 10)
                        
                        Button(action: {
                            showAvatarSelection = true
                        }) {
                            Image(systemName: "pencil.circle.fill")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .background(Color.white)
                                .clipShape(Circle())
                                .padding()
                        }
                    }
                    
                    Text("Unido desde: 10 de Julio, 2024")
                        .font(.footnote)
                        .foregroundColor(.gray)
                        .padding(.top, 5)
                }
                .frame(maxWidth: .infinity, alignment: .center)
                
                Form {
                    Section(header: Text("Información Personal")) {
                        TextField("Nombre", text: $firstName)
                        TextField("Apellido", text: $lastName)
                        TextField("Edad", text: .constant(age))
                            .disabled(true)
                        TextField("Tipo de Usuario", text: .constant(userType))
                            .disabled(true)
                    }

                    Section {
                        Button("Cerrar Sesión") {
                            showAlert = true
                        }
                        .foregroundColor(.red)
                        .alert(isPresented: $showAlert) {
                            Alert(
                                title: Text("Cerrar Sesión"),
                                message: Text("¿Estás seguro de que quieres cerrar sesión?"),
                                primaryButton: .destructive(Text("Cerrar Sesión")) {
                                    appState.isLoggedIn = false
                                },
                                secondaryButton: .cancel()
                            )
                        }
                    }
                }
            }
            .navigationTitle("Perfil")
            .sheet(isPresented: $showAvatarSelection) {
                AvatarSelectionView(selectedAvatar: $appState.selectedAvatar)
            }
        }
    }
}

struct AvatarSelectionView: View {
    @Binding var selectedAvatar: String
    
    let avatars = [
        "avatar1", "avatar2", "avatar3",
        "avatar4", "avatar5", "avatar6"
    ]
    
    var body: some View {
        VStack {
            Text("Selecciona un Avatar")
                .font(.title)
                .padding()
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                ForEach(avatars, id: \.self) { avatar in
                    Button(action: {
                        selectedAvatar = avatar
                    }) {
                        Image(avatar)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(selectedAvatar == avatar ? Color.blue : Color.clear, lineWidth: 3))
                    }
                }
            }
            .padding()
            
            Spacer()
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
            .environmentObject(AppState())
    }
}
