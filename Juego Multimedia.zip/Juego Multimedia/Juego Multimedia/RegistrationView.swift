import SwiftUI

struct RegistrationView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var age = 10
    @State private var userType = ""
    @State private var proficiencyLevel = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Información Personal")) {
                    TextField("Nombre", text: $firstName)
                    TextField("Apellido", text: $lastName)
                    TextField("Correo Electrónico", text: $email)
                        /*.keyboardType(.emailAddress)*/
                    SecureField("Contraseña", text: $password)
                    Picker("Edad", selection: $age) {
                        ForEach(5..<91) { age in
                            Text("\(age)").tag(age)
                        }
                    }
                }

                Section(header: Text("Información Adicional")) {
                    Picker("Tipo de Usuario", selection: $userType) {
                        Text("Estudiante Escuela").tag("Estudiante Escuela")
                        Text("Estudiante Colegio").tag("Estudiante Colegio")
                        Text("Estudiante Universitario").tag("Estudiante Universitario")
                    }
                    Picker("Nivel", selection: $proficiencyLevel) {
                        Text("Básico").tag("Básico")
                        Text("Intermedio").tag("Intermedio")
                        Text("Avanzado").tag("Avanzado")
                    }
                }

                Button("Registrarse") {
                    if email.isEmpty || password.isEmpty || firstName.isEmpty || lastName.isEmpty {
                        alertMessage = "Por favor, complete todos los campos."
                        showAlert = true
                    } else if !isValidEmailAddr(strToValidate: email) {
                        alertMessage = "Por favor, ingrese un correo electrónico válido."
                        showAlert = true
                    } else {
                        alertMessage = "Registro exitoso. Por favor, inicie sesión."
                        showAlert = true
                    }
                }
            }
            .navigationTitle("Registrarse")
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Registro"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    func isValidEmailAddr(strToValidate: String) -> Bool {
        let emailValidationRegex = "^[\\p{L}0-9!#$%&'*+/=?^_`{|}~-][\\p{L}0-9.!#$%&'*+/=?^_`{|}~-]{0,63}@[\\p{L}0-9-]+(?:\\.[\\p{L}0-9-]{2,7})*$"
        let emailValidationPredicate = NSPredicate(format: "SELF MATCHES %@", emailValidationRegex)
        return emailValidationPredicate.evaluate(with: strToValidate)
    }
}
