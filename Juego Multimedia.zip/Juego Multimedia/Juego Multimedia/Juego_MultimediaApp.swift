import SwiftUI

@main
struct Juego_MultimediaApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
        }
    }
}



// Asegúrate de que todas las vistas están definidas correctamente
struct VistaInicio: View {
    var body: some View {
        Text("Vista de Inicio")
    }
}

struct VistaEjercicios: View {
    var body: some View {
        Text("Vista de Ejercicios")
    }
}

struct VistaConfiguracion: View {
    var body: some View {
        Text("Vista de Configuración")
    }
}
