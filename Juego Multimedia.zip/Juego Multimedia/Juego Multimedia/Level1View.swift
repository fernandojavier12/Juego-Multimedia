//
//  Level1View.swift
//  Juego Multimedia
//
//  Created by Fernando Torres on 18/7/24.
//

import SwiftUI

struct Level1View: View {
    @State private var answers = Array(repeating: "", count: 10)
    @State private var score = 0
    @State private var showResult = false

    let questions = [
        Question(prompt: "I am going to the store.", options: ["Voy", "Ir", "Vamos", "Fui"], correctAnswer: "Voy"),
        Question(prompt: "She has been studying for a long time.", options: ["Esta", "Estoy", "Ha estado", "Estaba"], correctAnswer: "Ha estado"),
        Question(prompt: "They will be arriving soon.", options: ["Llegarán", "Llega", "Llegué", "Llegamos"], correctAnswer: "Llegarán"),
        Question(prompt: "I have not been to the movies in a long time.", options: ["No estuve", "No estás", "No estoy", "No he estado"], correctAnswer: "No he estado"),
        Question(prompt: "You will be able to see the movie tonight.", options: ["Pueden ver", "Puedo ver", "Podrás ver", "Puedes ver"], correctAnswer: "Podrás ver"),
        Question(prompt: "The book is on the table.", options: ["La mesa", "La ventana", "La silla", "El libro"], correctAnswer: "El libro"),
        Question(prompt: "She is reading a book.", options: ["Un libro", "La mesa", "La silla", "La ventana"], correctAnswer: "Un libro"),
        Question(prompt: "They are going to the park.", options: ["La oficina", "La casa", "El parque", "La tienda"], correctAnswer: "El parque"),
        Question(prompt: "This is my brother.", options: ["Mi hermana", "Mi madre", "Mi hermano", "Mi padre"], correctAnswer: "Mi hermano"),
        Question(prompt: "I am looking for my friend.", options: ["Mi amiga", "Mi amigo", "Mi hermano", "Mi hermana"], correctAnswer: "Mi amigo")
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Verbos")
                    .font(.largeTitle)
                    .padding(.bottom, 20)
                
                ForEach(0..<questions.count, id: \.self) { index in
                    VStack(alignment: .leading) {
                        Text(questions[index].prompt)
                        ForEach(questions[index].options, id: \.self) { option in
                            Button(action: {
                                answers[index] = option
                            }) {
                                HStack {
                                    Text(option)
                                    Spacer()
                                    if answers[index] == option {
                                        Image(systemName: "checkmark")
                                            .foregroundColor(.blue)
                                    }
                                }
                                .padding()
                                .background(Color(UIColor.systemGray5))
                                .cornerRadius(8)
                            }
                        }
                    }
                }

                Button(action: {
                    calculateScore()
                    showResult = true
                }) {
                    Text("Submit")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.top, 20)
                .alert(isPresented: $showResult) {
                    Alert(title: Text("Result"), message: Text(resultMessage()), dismissButton: .default(Text("OK")))
                }
            }
            .padding()
        }
    }

    func calculateScore() {
        score = 0
        for i in 0..<questions.count {
            if answers[i] == questions[i].correctAnswer {
                score += 100
            }
        }
    }

    func resultMessage() -> String {
        if score > 700 {
            return "Aprobaste el test con \(score) puntos"
        } else {
            return "Debe repetir el test porque no cuenta con la puntuación solicitada. Obtuviste \(score) puntos"
        }
    }
}
