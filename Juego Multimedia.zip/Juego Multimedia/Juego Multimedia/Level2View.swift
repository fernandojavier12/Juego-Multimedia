//
//  Level2View.swift
//  Juego Multimedia
//
//  Created by Fernando Torres on 18/7/24.
//

import SwiftUI

struct Level2View: View {
    @State private var answers = Array(repeating: "", count: 10)
    @State private var score = 0
    @State private var showResult = false

    let questions = [
        Question(prompt: "The new car is very expensive.", options: ["Muy", "Bien", "Mal", "Pequeño"], correctAnswer: "Muy"),
        Question(prompt: "I am going to the city tomorrow.", options: ["Ahora", "Mañana", "Ayer", "Hoy"], correctAnswer: "Mañana"),
        Question(prompt: "She is very happy.", options: ["Pequeño", "Mal", "Muy", "Bien"], correctAnswer: "Muy"),
        Question(prompt: "I am going to the store quickly.", options: ["Mal", "Rápidamente", "Lentamente", "Bien"], correctAnswer: "Rápidamente"),
        Question(prompt: "The new restaurant is very good.", options: ["Pequeño", "Mal", "Muy", "Bien"], correctAnswer: "Muy"),
        Question(prompt: "I am going to the store.", options: ["Voy", "Ir", "Vamos", "Fui"], correctAnswer: "Voy"),
        Question(prompt: "She has been studying for a long time.", options: ["Esta", "Estoy", "Ha estado", "Estaba"], correctAnswer: "Ha estado"),
        Question(prompt: "They will be arriving soon.", options: ["Llegamos", "Llegué", "Llegarán", "Llega"], correctAnswer: "Llegarán"),
        Question(prompt: "I have not been to the movies in a long time.", options: ["No estás", "No estuve", "No he estado", "No estoy"], correctAnswer: "No he estado"),
        Question(prompt: "You will be able to see the movie tonight.", options: ["Pueden ver", "Puedo ver", "Podrás ver", "Puedes ver"], correctAnswer: "Podrás ver")
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Adjetivos y Adverbios")
                    .font(.largeTitle)
                    .padding(.bottom, 20)
                
                ForEach(0..<questions.count, id: \.self) { index in
                    VStack(alignment: .leading) {
                        Text(questions[index].prompt)
                        ForEach(questions[index].options, id: \.self) { option in
                            Button(action: {
                                answers[index] = option
                            }) {
                                HStack {
                                    Text(option)
                                    Spacer()
                                    if answers[index] == option {
                                        Image(systemName: "checkmark")
                                            .foregroundColor(.blue)
                                    }
                                }
                                .padding()
                                .background(Color(UIColor.systemGray5))
                                .cornerRadius(8)
                            }
                        }
                    }
                }

                Button(action: {
                    calculateScore()
                    showResult = true
                }) {
                    Text("Submit")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.top, 20)
                .alert(isPresented: $showResult) {
                    Alert(title: Text("Result"), message: Text(resultMessage()), dismissButton: .default(Text("OK")))
                }
            }
            .padding()
        }
    }

    func calculateScore() {
        score = 0
        for i in 0..<questions.count {
            if answers[i] == questions[i].correctAnswer {
                score += 100
            }
        }
    }

    func resultMessage() -> String {
        if score > 700 {
            return "Aprobaste el test con \(score) puntos"
        } else {
            return "Debe repetir el test porque no cuenta con la puntuación solicitada. Obtuviste \(score) puntos"
        }
    }
}
