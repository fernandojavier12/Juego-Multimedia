import SwiftUI

struct LessonView: View {
    @State private var questionIndex = 0
    @State private var score = 0
    @State private var showAlert = false
    @State private var alertTitle = ""
    @EnvironmentObject var appState: AppState

    let questions = [
        ("Completa la frase: The cat is on the ___", ["table", "floor", "chair", "car"], "table"),
        ("Selecciona el par correcto: Run", ["Correr", "Comer", "Saltar", "Beber"], "Correr")
    ]

    var body: some View {
        VStack {
            Text("Lección")
                .font(.largeTitle)
                .padding()

            if questionIndex < questions.count {
                Text(questions[questionIndex].0)
                    .padding()

                ForEach(questions[questionIndex].1, id: \.self) { answer in
                    Button(action: {
                        checkAnswer(answer)
                    }) {
                        Text(answer)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    .padding(.vertical, 4)
                }
            } else {
                Text("Lección completada")
                    .padding()

                Text("Puntuación: \(score)")
                    .padding()

                Button(action: {
                    resetLesson()
                }) {
                    Text("Reiniciar Lección")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text(alertTitle), dismissButton: .default(Text("OK")))
        }
    }

    func checkAnswer(_ answer: String) {
        if answer == questions[questionIndex].2 {
            alertTitle = "Correcto"
            score += 100
            appState.score += 100
        } else {
            alertTitle = "Incorrecto"
        }
        showAlert = true
        questionIndex += 1
    }

    func resetLesson() {
        questionIndex = 0
        score = 0
    }
}
