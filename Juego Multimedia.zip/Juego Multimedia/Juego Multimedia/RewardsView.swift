import SwiftUI

struct RewardsView: View {
    var body: some View {
        VStack {
            Text("Recompensas")
                .font(.largeTitle)
                .padding()

            // Agrega el contenido de recompensas aquí
        }
        .navigationTitle("Recompensas")
    }
}
