import SwiftUI

struct RewardsView: View {
    var personalAchievements = [
        (imageName: "logro1", title: "Racha suprema", date: "17 jul 2024"),
        (imageName: "logro2", title: "En la cima", date: "26 jun 2024"),
        (imageName: "logro3", title: "Más EXP que", date: "3 feb 2024")
    ]

    var rewards = [
        (imageName: "reward1", title: "Semana perfecta", progress: "1 de 9"),
        (imageName: "reward2", title: "Ojo de halcón", progress: "4 de 5"),
        (imageName: "reward3", title: "Hazaña olímpica", progress: "6 de 10"),
        (imageName: "reward4", title: "Coleccionista", progress: "4 de 10"),
        (imageName: "reward5", title: "Desafiante", progress: "4 de 10"),
        (imageName: "reward6", title: "Libre de errores", progress: "3 de 10"),
        (imageName: "reward7", title: "Nuevo Recompensa 1", progress: "Progreso"),
        (imageName: "reward8", title: "Nuevo Recompensa 2", progress: "Progreso"),
        (imageName: "reward9", title: "Nuevo Recompensa 3", progress: "Progreso")
    ]
    
    var body: some View {
        
        ScrollView {
            VStack(alignment: .leading) {
                // Parte superior con la bandera, puntos de experiencia y días usando la aplicación
                HStack {
                    Image(systemName: "flag.fill")
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.red)

                    Spacer()

                    HStack(spacing: 16) {
                        HStack(spacing: 4) {
                            Image(systemName: "flame.fill")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.orange)
                            Text("153") // Datos específicos para RewardView
                        }

                        HStack(spacing: 4) {
                            Image("calen")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.blue)
                            Text("1360") // Datos específicos para RewardView
                        }

                        HStack(spacing: 4) {
                            Image(systemName: "heart.fill")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.red)
                            Text("5") // Datos específicos para RewardView
                        }

                        HStack(spacing: 4) {
                            Image(systemName: "sparkles")
                                .resizable()
                                .frame(width: 16, height: 16)
                                .foregroundColor(.purple)
                            Text("1") // Datos específicos para RewardView
                        }
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 5)
                .padding([.leading, .trailing, .top])

                Text("Logros personales")
                    .font(.title2)
                    .padding(.leading)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(personalAchievements, id: \.title) { achievement in
                            VStack {
                                Image(achievement.imageName)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .padding()
                                Text(achievement.title)
                                    .font(.caption)
                                Text(achievement.date)
                                    .font(.caption2)
                                    .foregroundColor(.gray)
                            }
                            .frame(width: 150)
                        }
                    }
                    .padding()
                }

                Text("Premios")
                    .font(.title2)
                    .padding(.leading)

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(rewards, id: \.title) { reward in
                        VStack {
                            Image(reward.imageName)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 75, height: 75)
                            Text(reward.title)
                                .font(.caption)
                            Text(reward.progress)
                                .font(.caption2)
                                .foregroundColor(.gray)
                        }
                        .padding()
                    }
                }
                .padding()
            }
        }
        .navigationTitle("Recompensas")
    }
}

struct RewardsView_Previews: PreviewProvider {
    static var previews: some View {
        RewardsView()
    }
}
