import SwiftUI

struct ChallengesView: View {
    let categories = [
        Category(name: "Palabras", imageName: "Palabras"),
        Category(name: "Números", imageName: "Números"),
        Category(name: "Animales", imageName: "Animales"),
        Category(name: "Frutas", imageName: "Frutas")
    ]

    var body: some View {
        NavigationView {
            VStack {
                Text("Retos Diarios")
                    .font(.title)
                    .padding()
                
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(categories) { category in
                        NavigationLink(destination: CategoryDetailView(category: category)) {
                            VStack {
                                Image(category.imageName)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .background(Color.white)
                                    .cornerRadius(10)
                                    .shadow(radius: 5)
                                
                                Text(category.name)
                                    .font(.headline)
                                    .foregroundColor(.black)
                            }
                            .padding()
                            .background(Color(UIColor.systemGray6))
                            .cornerRadius(10)
                            .shadow(radius: 5)
                        }
                    }
                }
                .padding()
                .background(Color.orange.opacity(0.2))
                .cornerRadius(20)
                .padding()
            }
            .background(Color.orange.edgesIgnoringSafeArea(.all))
            .navigationTitle("Retos")
        }
    }
}

struct Category: Identifiable {
    let id = UUID()
    let name: String
    let imageName: String
}

struct CategoryDetailView: View {
    let category: Category

    var body: some View {
        switch category.name {
        case "Palabras":
            WordSortingGameView()
                .navigationBarTitle(category.name, displayMode: .inline)
        case "Números":
            NumberMatchingGameView()
                .navigationBarTitle(category.name, displayMode: .inline)
        case "Animales":
            AnimalNameGameView()
                .navigationBarTitle(category.name, displayMode: .inline)
        case "Frutas":
            FruitDictationGameView()
                .navigationBarTitle(category.name, displayMode: .inline)
        default:
            Text("Detalles para \(category.name)")
                .font(.largeTitle)
                .navigationBarTitle(category.name, displayMode: .inline)
        }
    }
}

struct WordSortingGameView: View {
    @State private var lives = 5
    @State private var points = 0
    @State private var experience = 0
    @State private var currentSentence = ""
    @State private var shuffledWords = [String]()
    @State private var userAnswer = [String]()
    @State private var showAlert = false
    @State private var alertMessage = ""

    let sentences = [
        "My name is John.",
        "I am from the United States.",
        "I like to eat pizza.",
        "I have two brothers and one sister.",
        "I go to school every day.",
        "I play soccer on the weekends.",
        "The weather is sunny today.",
        "I speak English and Spanish.",
        "My favorite color is blue.",
        "I live in a house with my family."
    ]
    
    var body: some View {
        VStack {
            HStack {
                HStack {
                    Image(systemName: "heart.fill")
                        .foregroundColor(.red)
                    Text("Vidas: \(lives)")
                }
                Spacer()
                HStack {
                    Text("Puntos: \(points)")
                    Text("EXP: \(experience)")
                }
            }
            .padding()
            
            Spacer()
            
            if !shuffledWords.isEmpty {
                Text("Ordena las palabras para formar la oración:")
                    .font(.headline)
                    .padding()
                
                Text(currentSentence)
                    .hidden()
                
                HStack {
                    ForEach(userAnswer, id: \.self) { word in
                        Text(word)
                            .padding()
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(8)
                    }
                }
                .padding()
                
                HStack {
                    ForEach(shuffledWords, id: \.self) { word in
                        Button(action: {
                            userAnswer.append(word)
                            shuffledWords.removeAll { $0 == word }
                        }) {
                            Text(word)
                                .padding()
                                .background(Color.blue.opacity(0.2))
                                .cornerRadius(8)
                        }
                    }
                }
                .padding()
                
                Button("Comprobar") {
                    checkAnswer()
                }
                .padding()
            } else {
                Button("Iniciar Juego") {
                    startNewGame()
                }
                .padding()
            }
            
            Spacer()
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Mensaje"), message: Text(alertMessage), dismissButton: .default(Text("OK"), action: {
                if lives > 0 {
                    startNewGame()
                }
            }))
        }
    }
    
    private func startNewGame() {
        guard let randomSentence = sentences.randomElement() else { return }
        currentSentence = randomSentence
        shuffledWords = randomSentence
            .replacingOccurrences(of: ".", with: "")
            .split(separator: " ")
            .map { String($0) }
            .shuffled()
        userAnswer = []
    }
    
    private func checkAnswer() {
        let userSentence = userAnswer.joined(separator: " ") + "."
        if userSentence == currentSentence {
            points += 100
            experience += 50
            alertMessage = "¡Correcto! Ganaste 100 puntos y 50 EXP."
        } else {
            lives -= 1
            if lives == 0 {
                alertMessage = "Se acabaron las vidas. Inténtalo mañana."
            } else {
                alertMessage = "Incorrecto. Pierdes una vida."
            }
        }
        showAlert = true
    }
}

struct NumberMatchingGameView: View {
    @State private var lives = 5
    @State private var points = 0
    @State private var experience = 0
    @State private var numberPairs = [(String, String)]()
    @State private var selectedPairs = [(String, String)]()
    @State private var showAlert = false
    @State private var alertMessage = ""

    let numbers: [String: String] = [
        "1": "One", "2": "Two", "3": "Three", "4": "Four", "5": "Five",
        "6": "Six", "7": "Seven", "8": "Eight", "9": "Nine", "10": "Ten",
        "11": "Eleven", "12": "Twelve", "13": "Thirteen", "14": "Fourteen",
        "15": "Fifteen", "16": "Sixteen", "17": "Seventeen", "18": "Eighteen",
        "19": "Nineteen", "20": "Twenty"
    ]
    
    var body: some View {
        VStack {
            HStack {
                HStack {
                    Image(systemName: "heart.fill")
                        .foregroundColor(.red)
                    Text("Vidas: \(lives)")
                }
                Spacer()
                HStack {
                    Text("Puntos: \(points)")
                    Text("EXP: \(experience)")
                }
            }
            .padding()
            
            Spacer()
            
            ScrollView {
                VStack {
                    Text("Empareja los números con sus nombres:")
                        .font(.headline)
                        .padding()
                    
                    ForEach(0..<numberPairs.count, id: \.self) { index in
                        HStack {
                            Text(numberPairs[index].0)
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(8)
                            Spacer()
                            Text(numberPairs[index].1)
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(8)
                        }
                        .padding(.horizontal)
                    }
                }
                .padding()
            }
            
            Button("Comprobar") {
                checkAnswer()
            }
            .padding()
            
            Spacer()
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Mensaje"), message: Text(alertMessage), dismissButton: .default(Text("OK"), action: {
                if lives > 0 {
                    startNewGame()
                }
            }))
        }
        .onAppear {
            startNewGame()
        }
    }
    
    private func startNewGame() {
        lives = 5
        points = 0
        experience = 0
        numberPairs = numbers.shuffled().map { ($0.key, $0.value) }
        selectedPairs = []
    }
    
    private func checkAnswer() {
        let correctPairs = numberPairs.filter { numbers[$0.0] == $0.1 }
        if correctPairs.count == numberPairs.count {
            points += 100
            experience += 75
            alertMessage = "¡Correcto! Ganaste 100 puntos y 75 EXP."
        } else {
            lives -= 1
            if lives == 0 {
                alertMessage = "Se acabaron las vidas. Inténtalo mañana."
            } else {
                alertMessage = "Incorrecto. Pierdes una vida."
            }
        }
        showAlert = true
    }
}

struct AnimalNameGameView: View {
    @State private var lives = 5
    @State private var points = 0
    @State private var experience = 0
    @State private var animals = ["Dog", "Cat", "Horse", "Elephant", "Lion"]
    @State private var currentAnimal = ""
    @State private var userAnswer = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        VStack {
            HStack {
                HStack {
                    Image(systemName: "heart.fill")
                        .foregroundColor(.red)
                    Text("Vidas: \(lives)")
                }
                Spacer()
                HStack {
                    Text("Puntos: \(points)")
                    Text("EXP: \(experience)")
                }
            }
            .padding()
            
            Spacer()
            
            if !currentAnimal.isEmpty {
                Text("Adivina el nombre del animal:")
                    .font(.headline)
                    .padding()
                
                Image(currentAnimal)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
                    .padding()
                
                TextField("Tu respuesta", text: $userAnswer)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button("Comprobar") {
                    checkAnswer()
                }
                .padding()
            } else {
                Button("Iniciar Juego") {
                    startNewGame()
                }
                .padding()
            }
            
            Spacer()
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Mensaje"), message: Text(alertMessage), dismissButton: .default(Text("OK"), action: {
                if lives > 0 {
                    startNewGame()
                }
            }))
        }
    }
    
    private func startNewGame() {
        currentAnimal = animals.randomElement() ?? ""
        userAnswer = ""
    }
    
    private func checkAnswer() {
        if userAnswer.lowercased() == currentAnimal.lowercased() {
            points += 100
            experience += 50
            alertMessage = "¡Correcto! Ganaste 100 puntos y 50 EXP."
        } else {
            lives -= 1
            if lives == 0 {
                alertMessage = "Se acabaron las vidas. Inténtalo mañana."
            } else {
                alertMessage = "Incorrecto. Pierdes una vida."
            }
        }
        showAlert = true
    }
}

struct FruitDictationGameView: View {
    @State private var lives = 5
    @State private var points = 0
    @State private var experience = 0
    @State private var fruits = ["Apple", "Banana", "Strawberry", "Orange", "Pineapple", "Grape"]
    @State private var currentFruit = ""
    @State private var userAnswer = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        VStack {
            HStack {
                HStack {
                    Image(systemName: "heart.fill")
                        .foregroundColor(.red)
                    Text("Vidas: \(lives)")
                }
                Spacer()
                HStack {
                    Text("Puntos: \(points)")
                    Text("EXP: \(experience)")
                }
            }
            .padding()
            
            Spacer()
            
            if !currentFruit.isEmpty {
                Text("Escribe el nombre de la fruta:")
                    .font(.headline)
                    .padding()
                
                Image(currentFruit)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
                    .padding()
                
                TextField("Tu respuesta", text: $userAnswer)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button("Comprobar") {
                    checkAnswer()
                }
                .padding()
            } else {
                Button("Iniciar Juego") {
                    startNewGame()
                }
                .padding()
            }
            
            Spacer()
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Mensaje"), message: Text(alertMessage), dismissButton: .default(Text("OK"), action: {
                if lives > 0 {
                    startNewGame()
                }
            }))
        }
    }
    
    private func startNewGame() {
        currentFruit = fruits.randomElement() ?? ""
        userAnswer = ""
    }
    
    private func checkAnswer() {
        if userAnswer.lowercased() == currentFruit.lowercased() {
            points += 100
            experience += 50
            alertMessage = "¡Correcto! Ganaste 100 puntos y 50 EXP."
        } else {
            lives -= 1
            if lives == 0 {
                alertMessage = "Se acabaron las vidas. Inténtalo mañana."
            } else {
                alertMessage = "Incorrecto. Pierdes una vida."
            }
        }
        showAlert = true
    }
}

struct ChallengesView_Previews: PreviewProvider {
    static var previews: some View {
        ChallengesView()
    }
}
