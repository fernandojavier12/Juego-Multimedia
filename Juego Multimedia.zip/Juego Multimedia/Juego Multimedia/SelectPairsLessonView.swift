import SwiftUI

struct SelectPairsLessonView: View {
    @EnvironmentObject var appState: AppState
    @State private var selectedPair: String? = nil
    @State private var showAlert = false
    @State private var alertMessage = ""

    let pairs = [
        "run": "correr",
        "eat": "volar",
        "write": "hablar",
        "speak": "escribir"
    ]
    
    var body: some View {
        VStack {
            Text("Selecciona el par correcto:")
            ForEach(pairs.keys.sorted(), id: \.self) { key in
                Button("\(key) - \(pairs[key]!)") {
                    selectedPair = key
                    checkAnswer()
                }
                .padding()
                .background(Color.blue.opacity(0.2))
                .cornerRadius(10)
            }
        }
        .navigationTitle("Seleccionar pares")
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Resultado"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    func checkAnswer() {
        if selectedPair == "run" { // Ejemplo de respuesta correcta
            appState.score += 100
            alertMessage = "¡Correcto! Ganaste 100 puntos."
        } else {
            alertMessage = "Respuesta incorrecta. Inténtalo de nuevo."
        }
        showAlert = true
    }
}
