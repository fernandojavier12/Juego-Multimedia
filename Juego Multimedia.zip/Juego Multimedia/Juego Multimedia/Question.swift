//
//  Question.swift
//  Juego Multimedia
//
//  Created by Fernando Torres on 18/7/24.
//

import Foundation

struct Question {
    let prompt: String
    let options: [String]
    let correctAnswer: String
}
